print('zdir/__main__')

# imports should be resolved relative to top of zdir.zip
import mod

# sys.argv
import sys
print(sys.argv)

# variable in module namespace
tag = '~~ZDIR/MAIN~~'
