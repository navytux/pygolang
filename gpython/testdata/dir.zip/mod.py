print('zdir/mod')

# variable in module namespace
tag = '~~ZDIR/MOD~~'
