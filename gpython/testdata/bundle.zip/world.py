print('zworld')

# variable in module namespace
tag = '~~ZWORLD~~'
