print('zpkg/mod')

# variable in module namespace
tag = '~~ZPKG/MOD~~'
