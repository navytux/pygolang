print('zhello')

# imports should be resolved relative to main py file
import world

# sys.argv
import sys
print(sys.argv)

# variable in module namespace
tag = '~~ZHELLO~~'
